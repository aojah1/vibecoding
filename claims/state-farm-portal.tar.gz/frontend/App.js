import React from 'react';
import StateFarmLivePortal from './StateFarmLivePortal';
import './App.css';

function App() {
  return (
    <div className="App">
      <StateFarmLivePortal />
    </div>
  );
}

export default App;
