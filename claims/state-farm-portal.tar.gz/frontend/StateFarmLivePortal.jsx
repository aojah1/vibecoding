import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

const COLORS = ['#E31837', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
const API_BASE = 'http://localhost:3001/api';

export default function StateFarmLivePortal() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('connecting');
  
  // State for live data
  const [claimsData, setClaimsData] = useState([]);
  const [adjustersData, setAdjustersData] = useState([]);
  const [damagesData, setDamagesData] = useState([]);
  const [statsData, setStatsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch all data from API
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Check backend health
        const healthRes = await fetch('http://localhost:3001/health');
        const health = await healthRes.json();
        
        if (health.status === 'healthy') {
          setConnectionStatus('connected');
        }

        // Fetch all data in parallel
        const [claimsRes, adjustersRes, damagesRes, statsRes] = await Promise.all([
          fetch(`${API_BASE}/claims`),
          fetch(`${API_BASE}/adjusters`),
          fetch(`${API_BASE}/damages`),
          fetch(`${API_BASE}/stats`)
        ]);

        const [claims, adjusters, damages, stats] = await Promise.all([
          claimsRes.json(),
          adjustersRes.json(),
          damagesRes.json(),
          statsRes.json()
        ]);

        if (claims.success) setClaimsData(claims.data);
        if (adjusters.success) setAdjustersData(adjusters.data);
        if (damages.success) setDamagesData(damages.data);
        if (stats.success) setStatsData(stats.data);

        setLoading(false);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(err.message);
        setConnectionStatus('disconnected');
        setLoading(false);
      }
    };

    fetchData();
    
    // Refresh data every 30 seconds
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  // Calculate metrics from live data
  const getStat = (metric) => {
    const stat = statsData.find(s => s.METRIC === metric);
    return stat ? stat.VALUE : 0;
  };

  const totalClaims = getStat('Total Claims');
  const urgentClaims = getStat('Urgent Claims');
  const highPriority = getStat('High Priority');
  const unassigned = getStat('Unassigned');
  const totalEstimatedLoss = claimsData.reduce((sum, c) => sum + (c.ESTIMATED_LOSS || 0), 0);
  const avgAIConfidence = claimsData.filter(c => c.AI_CONFIDENCE_SCORE).length > 0
    ? claimsData.filter(c => c.AI_CONFIDENCE_SCORE).reduce((sum, c, _, arr) => sum + c.AI_CONFIDENCE_SCORE / arr.length, 0)
    : 0;

  const claimsByType = [
    { name: 'WATER', value: claimsData.filter(c => c.CLAIM_SUBTYPE === 'WATER').length },
    { name: 'STORM', value: claimsData.filter(c => c.CLAIM_SUBTYPE === 'STORM').length },
    { name: 'FIRE', value: claimsData.filter(c => c.CLAIM_SUBTYPE === 'FIRE').length },
    { name: 'THEFT', value: claimsData.filter(c => c.CLAIM_SUBTYPE === 'THEFT').length },
    { name: 'INJURY', value: claimsData.filter(c => c.CLAIM_SUBTYPE === 'INJURY').length }
  ].filter(t => t.value > 0);

  const claimsByStatus = [
    { name: 'INITIATED', value: claimsData.filter(c => c.STATUS === 'INITIATED').length },
    { name: 'INTAKE_COMPLETE', value: claimsData.filter(c => c.STATUS === 'INTAKE_COMPLETE').length },
    { name: 'ASSIGNED', value: claimsData.filter(c => c.STATUS === 'ASSIGNED').length },
    { name: 'INVESTIGATING', value: claimsData.filter(c => c.STATUS === 'INVESTIGATING').length },
    { name: 'UNDER_REVIEW', value: claimsData.filter(c => c.STATUS === 'UNDER_REVIEW').length }
  ].filter(s => s.value > 0);

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'claims', label: 'Claims', icon: '📋' },
    { id: 'adjusters', label: 'Adjusters', icon: '👔' },
    { id: 'damages', label: 'Damages', icon: '💰' },
    { id: 'ai-insights', label: 'AI Insights', icon: '🤖' }
  ];

  if (loading && claimsData.length === 0) {
    return (
      <div style={{ minHeight: '100vh', backgroundColor: '#111827', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>⏳</div>
          <h2 style={{ fontSize: '2rem', fontWeight: 'bold' }}>Loading Live Data...</h2>
          <p style={{ color: '#9ca3af', marginTop: '0.5rem' }}>Connecting to VIBECODING_MEDIUM</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ minHeight: '100vh', backgroundColor: '#111827', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', maxWidth: '600px', padding: '2rem' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>❌</div>
          <h2 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#ef4444' }}>Connection Error</h2>
          <p style={{ color: '#9ca3af', marginTop: '1rem' }}>Could not connect to the backend API</p>
          <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: '#1f2937', borderRadius: '0.5rem', textAlign: 'left' }}>
            <p style={{ fontSize: '0.875rem', marginBottom: '0.5rem' }}>Make sure the backend server is running:</p>
            <code style={{ display: 'block', padding: '0.5rem', backgroundColor: '#111827', borderRadius: '0.25rem', fontSize: '0.875rem' }}>
              cd backend && node server.js
            </code>
          </div>
          <button 
            onClick={() => window.location.reload()} 
            style={{ marginTop: '1rem', padding: '0.75rem 1.5rem', backgroundColor: '#dc2626', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontSize: '1rem', fontWeight: '500' }}
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#111827', color: 'white' }}>
      {/* Header */}
      <header style={{ background: 'linear-gradient(to right, #b91c1c, #7f1d1d)', padding: '1rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', borderBottom: '2px solid #dc2626' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', maxWidth: '1400px', margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ width: '3rem', height: '3rem', backgroundColor: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
              <span style={{ color: '#b91c1c', fontWeight: 'bold', fontSize: '1.5rem' }}>SF</span>
            </div>
            <div>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>State Farm AI Analytics Portal</h1>
              <p style={{ color: '#fca5a5', fontSize: '0.875rem', margin: 0 }}>🔴 Live Data from VIBECODING_MEDIUM • Oracle Autonomous Database</p>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem', borderRadius: '0.5rem', backgroundColor: connectionStatus === 'connected' ? '#10b981' : '#eab308' }}>
              <div style={{ width: '0.75rem', height: '0.75rem', borderRadius: '50%', backgroundColor: connectionStatus === 'connected' ? '#d1fae5' : '#fef9c3', animation: connectionStatus === 'connected' ? 'pulse 2s infinite' : 'none' }} />
              <span style={{ fontWeight: '500' }}>{connectionStatus === 'connected' ? '● LIVE' : 'Connecting...'}</span>
            </div>
            <div style={{ fontSize: '0.875rem', color: '#fca5a5' }}>Port: 6100</div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav style={{ backgroundColor: '#1f2937', borderBottom: '1px solid #374151' }}>
        <div style={{ display: 'flex', maxWidth: '1400px', margin: '0 auto' }}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: '1rem 1.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'all 0.2s',
                fontWeight: '500',
                backgroundColor: activeTab === tab.id ? '#b91c1c' : 'transparent',
                color: activeTab === tab.id ? 'white' : '#9ca3af',
                borderBottom: activeTab === tab.id ? '4px solid #dc2626' : 'none',
                border: 'none',
                cursor: 'pointer',
                fontSize: '1rem'
              }}
            >
              <span style={{ fontSize: '1.25rem' }}>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Main Content */}
      <main style={{ padding: '2rem', maxWidth: '1400px', margin: '0 auto' }}>
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* KPI Cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '1rem' }}>
              <div style={{ background: 'linear-gradient(135deg, #2563eb, #1e40af)', borderRadius: '0.75rem', padding: '1.25rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
                <div style={{ color: '#bfdbfe', fontSize: '0.875rem', fontWeight: '500' }}>Total Claims</div>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>{totalClaims}</div>
                <div style={{ color: '#dbeafe', fontSize: '0.75rem', marginTop: '0.25rem' }}>Active in system</div>
              </div>
              <div style={{ background: 'linear-gradient(135deg, #dc2626, #991b1b)', borderRadius: '0.75rem', padding: '1.25rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
                <div style={{ color: '#fca5a5', fontSize: '0.875rem', fontWeight: '500' }}>Urgent</div>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>{urgentClaims}</div>
                <div style={{ color: '#fecaca', fontSize: '0.75rem', marginTop: '0.25rem' }}>Immediate attention</div>
              </div>
              <div style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)', borderRadius: '0.75rem', padding: '1.25rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
                <div style={{ color: '#fcd34d', fontSize: '0.875rem', fontWeight: '500' }}>High Priority</div>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>{highPriority}</div>
                <div style={{ color: '#fde68a', fontSize: '0.75rem', marginTop: '0.25rem' }}>Needs review</div>
              </div>
              <div style={{ background: 'linear-gradient(135deg, #eab308, #ca8a04)', borderRadius: '0.75rem', padding: '1.25rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
                <div style={{ color: '#fde047', fontSize: '0.875rem', fontWeight: '500' }}>Unassigned</div>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>{unassigned}</div>
                <div style={{ color: '#fef08a', fontSize: '0.75rem', marginTop: '0.25rem' }}>Need adjuster</div>
              </div>
              <div style={{ background: 'linear-gradient(135deg, #10b981, #059669)', borderRadius: '0.75rem', padding: '1.25rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
                <div style={{ color: '#6ee7b7', fontSize: '0.875rem', fontWeight: '500' }}>Est. Loss</div>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', marginTop: '0.5rem' }}>${(totalEstimatedLoss/1000).toFixed(0)}K</div>
                <div style={{ color: '#a7f3d0', fontSize: '0.75rem', marginTop: '0.25rem' }}>Total reported</div>
              </div>
              <div style={{ background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)', borderRadius: '0.75rem', padding: '1.25rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}>
                <div style={{ color: '#c4b5fd', fontSize: '0.875rem', fontWeight: '500' }}>AI Confidence</div>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>{avgAIConfidence.toFixed(1)}%</div>
                <div style={{ color: '#ddd6fe', fontSize: '0.75rem', marginTop: '0.25rem' }}>Average score</div>
              </div>
            </div>

            {/* Charts */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', border: '1px solid #374151' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span>📊</span> Claims by Type
                </h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie data={claimsByType} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                      {claimsByType.map((entry, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', border: '1px solid #374151' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span>📈</span> Claims by Status
                </h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={claimsByStatus}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="name" tick={{ fill: '#9CA3AF', fontSize: 11 }} angle={-30} textAnchor="end" height={100} />
                    <YAxis tick={{ fill: '#9CA3AF' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px' }} />
                    <Bar dataKey="value" fill="#E31837" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Live Claims Table */}
            <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', border: '1px solid #374151', overflow: 'hidden' }}>
              <div style={{ padding: '1.5rem', borderBottom: '1px solid #374151' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '0.5rem', margin: 0 }}>
                  <span style={{ fontSize: '1.5rem', color: '#ef4444' }}>🔴</span> Live Claims Feed from VIBECODING_MEDIUM
                </h3>
              </div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead style={{ backgroundColor: '#374151' }}>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Claim #</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Type</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Customer</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Status</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Priority</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>AI Conf.</th>
                      <th style={{ textAlign: 'right', padding: '1rem', fontWeight: '600' }}>Est. Loss</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Adjuster</th>
                    </tr>
                  </thead>
                  <tbody>
                    {claimsData.map((claim) => (
                      <tr 
                        key={claim.CLAIM_ID} 
                        style={{ borderBottom: '1px solid #374151', cursor: 'pointer' }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#374151'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                        onClick={() => { setSelectedClaim(claim); setActiveTab('claims'); }}
                      >
                        <td style={{ padding: '1rem' }}>
                          <div style={{ color: '#f87171', fontWeight: '600' }}>{claim.CLAIM_NUMBER}</div>
                          <div style={{ color: '#6b7280', fontSize: '0.75rem' }}>{claim.INCIDENT_DATE}</div>
                        </td>
                        <td style={{ padding: '1rem' }}>
                          <div style={{ fontWeight: '500' }}>{claim.CLAIM_SUBTYPE}</div>
                          <div style={{ color: '#9ca3af', fontSize: '0.75rem' }}>{claim.PERIL_CODE}</div>
                        </td>
                        <td style={{ padding: '1rem' }}>{claim.CUSTOMER_NAME}</td>
                        <td style={{ padding: '1rem' }}>
                          <span style={{
                            padding: '0.25rem 0.75rem',
                            borderRadius: '9999px',
                            fontSize: '0.75rem',
                            fontWeight: '500',
                            backgroundColor: claim.STATUS === 'INVESTIGATING' ? '#78350f' : claim.STATUS === 'ASSIGNED' ? '#065f46' : '#1e40af',
                            color: claim.STATUS === 'INVESTIGATING' ? '#fde68a' : claim.STATUS === 'ASSIGNED' ? '#6ee7b7' : '#bfdbfe'
                          }}>
                            {claim.STATUS}
                          </span>
                        </td>
                        <td style={{ padding: '1rem' }}>
                          <span style={{
                            padding: '0.25rem 0.75rem',
                            borderRadius: '9999px',
                            fontSize: '0.75rem',
                            fontWeight: 'bold',
                            backgroundColor: claim.PRIORITY === 'URGENT' ? '#dc2626' : claim.PRIORITY === 'HIGH' ? '#f59e0b' : '#6b7280',
                            color: 'white'
                          }}>
                            {claim.PRIORITY}
                          </span>
                        </td>
                        <td style={{ padding: '1rem' }}>
                          {claim.AI_CONFIDENCE_SCORE ? (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                              <div style={{ width: '4rem', height: '0.5rem', backgroundColor: '#374151', borderRadius: '9999px', overflow: 'hidden' }}>
                                <div style={{ width: `${claim.AI_CONFIDENCE_SCORE}%`, height: '100%', backgroundColor: '#a855f7' }} />
                              </div>
                              <span style={{ fontSize: '0.875rem', fontWeight: '500' }}>{claim.AI_CONFIDENCE_SCORE}%</span>
                            </div>
                          ) : '-'}
                        </td>
                        <td style={{ padding: '1rem', textAlign: 'right', fontWeight: '600' }}>
                          {claim.ESTIMATED_LOSS ? `$${claim.ESTIMATED_LOSS.toLocaleString()}` : '-'}
                        </td>
                        <td style={{ padding: '1rem' }}>
                          {claim.ADJUSTER_NAME || <span style={{ color: '#6b7280', fontStyle: 'italic' }}>Unassigned</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Claims Detail Tab */}
        {activeTab === 'claims' && (
          <div style={{ display: 'grid', gridTemplateColumns: selectedClaim ? '2fr 1fr' : '1fr', gap: '1.5rem' }}>
            {selectedClaim ? (
              <>
                <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '1.5rem', border: '1px solid #374151' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '1.5rem' }}>
                    <div>
                      <h3 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#f87171', margin: 0 }}>{selectedClaim.CLAIM_NUMBER}</h3>
                      <p style={{ color: '#9ca3af', margin: '0.25rem 0 0 0' }}>{selectedClaim.CLAIM_TYPE} - {selectedClaim.CLAIM_SUBTYPE}</p>
                    </div>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <button 
                        onClick={() => setSelectedClaim(null)}
                        style={{ padding: '0.5rem 1rem', borderRadius: '0.5rem', backgroundColor: '#374151', color: 'white', border: 'none', cursor: 'pointer', fontWeight: '500' }}
                      >
                        ← Back to List
                      </button>
                      <span style={{
                        padding: '0.5rem 1rem',
                        borderRadius: '0.5rem',
                        fontWeight: 'bold',
                        backgroundColor: selectedClaim.PRIORITY === 'URGENT' ? '#dc2626' : selectedClaim.PRIORITY === 'HIGH' ? '#f59e0b' : '#6b7280'
                      }}>
                        {selectedClaim.PRIORITY}
                      </span>
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', fontSize: '0.875rem' }}>
                    <div><span style={{ color: '#9ca3af' }}>Customer:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.CUSTOMER_NAME}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Policy:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.POLICY_NUMBER}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Email:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.CUSTOMER_EMAIL}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Phone:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.CUSTOMER_PHONE}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Incident Date:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.INCIDENT_DATE}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Peril Code:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.PERIL_CODE}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Status:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.STATUS}</span></div>
                    <div><span style={{ color: '#9ca3af' }}>Adjuster:</span> <span style={{ fontWeight: '600', marginLeft: '0.5rem' }}>{selectedClaim.ADJUSTER_NAME || 'Unassigned'}</span></div>
                  </div>
                  {selectedClaim.AI_CONFIDENCE_SCORE && (
                    <div style={{ marginTop: '1.5rem', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '0.5rem', padding: '1rem', border: '1px solid #7c3aed' }}>
                      <div style={{ color: '#c4b5fd', fontWeight: '600', marginBottom: '0.5rem' }}>🤖 AI Analysis</div>
                      <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#a855f7' }}>{selectedClaim.AI_CONFIDENCE_SCORE}%</div>
                      <div style={{ color: '#c4b5fd', fontSize: '0.875rem' }}>Classification Confidence</div>
                    </div>
                  )}
                </div>
                <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '1.5rem', border: '1px solid #374151' }}>
                  <h4 style={{ fontWeight: '600', marginBottom: '1rem', fontSize: '1.125rem' }}>Quick Stats</h4>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div style={{ padding: '1rem', backgroundColor: '#111827', borderRadius: '0.5rem' }}>
                      <div style={{ color: '#9ca3af', fontSize: '0.875rem' }}>Estimated Loss</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981' }}>
                        {selectedClaim.ESTIMATED_LOSS ? `$${selectedClaim.ESTIMATED_LOSS.toLocaleString()}` : 'Not Estimated'}
                      </div>
                    </div>
                    <div style={{ padding: '1rem', backgroundColor: '#111827', borderRadius: '0.5rem' }}>
                      <div style={{ color: '#9ca3af', fontSize: '0.875rem' }}>Policy Number</div>
                      <div style={{ fontSize: '1.125rem', fontWeight: '600' }}>{selectedClaim.POLICY_NUMBER}</div>
                    </div>
                    <div style={{ padding: '1rem', backgroundColor: '#111827', borderRadius: '0.5rem' }}>
                      <div style={{ color: '#9ca3af', fontSize: '0.875rem' }}>Peril</div>
                      <div style={{ fontSize: '1.125rem', fontWeight: '600' }}>{selectedClaim.PERIL_CODE}</div>
                    </div>
                    <div style={{ padding: '1rem', backgroundColor: '#111827', borderRadius: '0.5rem' }}>
                      <div style={{ color: '#9ca3af', fontSize: '0.875rem' }}>Contact</div>
                      <div style={{ fontSize: '0.875rem', marginTop: '0.25rem' }}>{selectedClaim.CUSTOMER_EMAIL}</div>
                      <div style={{ fontSize: '0.875rem', marginTop: '0.25rem' }}>{selectedClaim.CUSTOMER_PHONE}</div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '3rem', textAlign: 'center', border: '1px solid #374151' }}>
                <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>📋</div>
                <h3 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '0.5rem' }}>Select a Claim</h3>
                <p style={{ color: '#9ca3af' }}>Click on a claim from the dashboard to view details</p>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  style={{ marginTop: '1.5rem', padding: '0.75rem 1.5rem', backgroundColor: '#dc2626', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontSize: '1rem', fontWeight: '500' }}
                >
                  Go to Dashboard
                </button>
              </div>
            )}
          </div>
        )}

        {/* Adjusters Tab */}
        {activeTab === 'adjusters' && (
          <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', border: '1px solid #374151', overflow: 'hidden' }}>
            <div style={{ padding: '1.5rem', borderBottom: '1px solid #374151' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '600', margin: 0 }}>👔 Active Adjusters</h3>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead style={{ backgroundColor: '#374151' }}>
                  <tr>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Adjuster ID</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Name</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Email</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Phone</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Specialization</th>
                    <th style={{ textAlign: 'center', padding: '1rem', fontWeight: '600' }}>Active Cases</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {adjustersData.map((adjuster) => (
                    <tr 
                      key={adjuster.ADJUSTER_ID} 
                      style={{ borderBottom: '1px solid #374151' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#374151'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                      <td style={{ padding: '1rem', fontWeight: '600', color: '#60a5fa' }}>{adjuster.ADJUSTER_ID}</td>
                      <td style={{ padding: '1rem', fontWeight: '500' }}>{adjuster.ADJUSTER_NAME}</td>
                      <td style={{ padding: '1rem', fontSize: '0.875rem', color: '#9ca3af' }}>{adjuster.EMAIL}</td>
                      <td style={{ padding: '1rem', fontSize: '0.875rem' }}>{adjuster.PHONE}</td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{
                          padding: '0.25rem 0.75rem',
                          borderRadius: '9999px',
                          fontSize: '0.75rem',
                          fontWeight: '500',
                          backgroundColor: '#1e40af',
                          color: '#bfdbfe'
                        }}>
                          {adjuster.SPECIALIZATION || 'General'}
                        </span>
                      </td>
                      <td style={{ padding: '1rem', textAlign: 'center', fontSize: '1.25rem', fontWeight: 'bold', color: '#10b981' }}>
                        {claimsData.filter(c => c.ADJUSTER_ID === adjuster.ADJUSTER_ID).length}
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{
                          padding: '0.25rem 0.75rem',
                          borderRadius: '9999px',
                          fontSize: '0.75rem',
                          fontWeight: '500',
                          backgroundColor: '#065f46',
                          color: '#6ee7b7'
                        }}>
                          ACTIVE
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Damages Tab */}
        {activeTab === 'damages' && (
          <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', border: '1px solid #374151', overflow: 'hidden' }}>
            <div style={{ padding: '1.5rem', borderBottom: '1px solid #374151' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '600', margin: 0 }}>💰 Damage Assessments</h3>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead style={{ backgroundColor: '#374151' }}>
                  <tr>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Damage ID</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Claim #</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Type</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Description</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Severity</th>
                    <th style={{ textAlign: 'right', padding: '1rem', fontWeight: '600' }}>Estimated Cost</th>
                    <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Assessment Date</th>
                  </tr>
                </thead>
                <tbody>
                  {damagesData.map((damage) => (
                    <tr 
                      key={damage.DAMAGE_ID} 
                      style={{ borderBottom: '1px solid #374151' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#374151'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                      <td style={{ padding: '1rem', fontWeight: '600', color: '#60a5fa' }}>{damage.DAMAGE_ID}</td>
                      <td style={{ padding: '1rem', color: '#f87171' }}>
                        {claimsData.find(c => c.CLAIM_ID === damage.CLAIM_ID)?.CLAIM_NUMBER || damage.CLAIM_ID}
                      </td>
                      <td style={{ padding: '1rem', fontWeight: '500' }}>{damage.DAMAGE_TYPE}</td>
                      <td style={{ padding: '1rem', fontSize: '0.875rem', color: '#9ca3af', maxWidth: '300px' }}>
                        {damage.DAMAGE_DESCRIPTION}
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{
                          padding: '0.25rem 0.75rem',
                          borderRadius: '9999px',
                          fontSize: '0.75rem',
                          fontWeight: 'bold',
                          backgroundColor: 
                            damage.SEVERITY === 'SEVERE' ? '#dc2626' : 
                            damage.SEVERITY === 'MODERATE' ? '#f59e0b' : 
                            '#10b981',
                          color: 'white'
                        }}>
                          {damage.SEVERITY}
                        </span>
                      </td>
                      <td style={{ padding: '1rem', textAlign: 'right', fontWeight: '600', fontSize: '1.125rem', color: '#10b981' }}>
                        {damage.ESTIMATED_REPAIR_COST ? `$${damage.ESTIMATED_REPAIR_COST.toLocaleString()}` : '-'}
                      </td>
                      <td style={{ padding: '1rem', fontSize: '0.875rem' }}>{damage.ASSESSMENT_DATE}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* AI Insights Tab */}
        {activeTab === 'ai-insights' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '1.5rem', border: '1px solid #374151' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span>🤖</span> AI-Powered Insights
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
                <div style={{ padding: '1.5rem', background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)', borderRadius: '0.75rem' }}>
                  <div style={{ color: '#ddd6fe', fontSize: '0.875rem', fontWeight: '500' }}>Average AI Confidence</div>
                  <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>{avgAIConfidence.toFixed(1)}%</div>
                  <div style={{ color: '#e9d5ff', fontSize: '0.75rem', marginTop: '0.25rem' }}>Across all claims</div>
                </div>
                <div style={{ padding: '1.5rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', borderRadius: '0.75rem' }}>
                  <div style={{ color: '#cffafe', fontSize: '0.875rem', fontWeight: '500' }}>High Confidence Claims</div>
                  <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>
                    {claimsData.filter(c => c.AI_CONFIDENCE_SCORE >= 85).length}
                  </div>
                  <div style={{ color: '#e0f2fe', fontSize: '0.75rem', marginTop: '0.25rem' }}>≥ 85% confidence</div>
                </div>
                <div style={{ padding: '1.5rem', background: 'linear-gradient(135deg, #ec4899, #db2777)', borderRadius: '0.75rem' }}>
                  <div style={{ color: '#fce7f3', fontSize: '0.875rem', fontWeight: '500' }}>Needs Review</div>
                  <div style={{ fontSize: '2.5rem', fontWeight: 'bold', marginTop: '0.5rem' }}>
                    {claimsData.filter(c => c.AI_CONFIDENCE_SCORE && c.AI_CONFIDENCE_SCORE < 70).length}
                  </div>
                  <div style={{ color: '#fce7f3', fontSize: '0.75rem', marginTop: '0.25rem' }}>< 70% confidence</div>
                </div>
              </div>
            </div>
            
            <div style={{ backgroundColor: '#1f2937', borderRadius: '0.75rem', padding: '1.5rem', border: '1px solid #374151' }}>
              <h4 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '1rem' }}>Claims Requiring AI Review</h4>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead style={{ backgroundColor: '#374151' }}>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Claim #</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Type</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>AI Confidence</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Reason</th>
                      <th style={{ textAlign: 'left', padding: '1rem', fontWeight: '600' }}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {claimsData
                      .filter(c => c.AI_CONFIDENCE_SCORE && c.AI_CONFIDENCE_SCORE < 80)
                      .sort((a, b) => a.AI_CONFIDENCE_SCORE - b.AI_CONFIDENCE_SCORE)
                      .map((claim) => (
                        <tr 
                          key={claim.CLAIM_ID} 
                          style={{ borderBottom: '1px solid #374151' }}
                          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#374151'}
                          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                        >
                          <td style={{ padding: '1rem', fontWeight: '600', color: '#f87171' }}>{claim.CLAIM_NUMBER}</td>
                          <td style={{ padding: '1rem' }}>{claim.CLAIM_SUBTYPE}</td>
                          <td style={{ padding: '1rem' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                              <div style={{ width: '5rem', height: '0.5rem', backgroundColor: '#374151', borderRadius: '9999px', overflow: 'hidden' }}>
                                <div style={{ 
                                  width: `${claim.AI_CONFIDENCE_SCORE}%`, 
                                  height: '100%', 
                                  backgroundColor: claim.AI_CONFIDENCE_SCORE < 50 ? '#dc2626' : claim.AI_CONFIDENCE_SCORE < 70 ? '#f59e0b' : '#a855f7'
                                }} />
                              </div>
                              <span style={{ fontSize: '0.875rem', fontWeight: '600' }}>{claim.AI_CONFIDENCE_SCORE}%</span>
                            </div>
                          </td>
                          <td style={{ padding: '1rem', fontSize: '0.875rem', color: '#9ca3af' }}>
                            {claim.AI_CONFIDENCE_SCORE < 50 ? 'Very Low Confidence' : 
                             claim.AI_CONFIDENCE_SCORE < 70 ? 'Low Confidence' : 
                             'Moderate Confidence'}
                          </td>
                          <td style={{ padding: '1rem' }}>
                            <button
                              onClick={() => { setSelectedClaim(claim); setActiveTab('claims'); }}
                              style={{ 
                                padding: '0.5rem 1rem', 
                                backgroundColor: '#7c3aed', 
                                color: 'white', 
                                border: 'none', 
                                borderRadius: '0.5rem', 
                                cursor: 'pointer', 
                                fontSize: '0.875rem', 
                                fontWeight: '500' 
                              }}
                            >
                              Review Claim
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
