import express from "express";
import cors from "cors";
import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();

const PORT = process.env.PORT || 3001;
const DB_USER = process.env.DB_USER || "ADMIN";
const DB_PASSWORD = process.env.DB_PASSWORD;
const DB_CONNECT_STRING = process.env.DB_CONNECT_STRING || "vibecoding_medium";
const TNS_ADMIN = process.env.TNS_ADMIN;
const WALLET_PASSWORD = process.env.WALLET_PASSWORD;

// Configure Oracle client
if (TNS_ADMIN) {
  process.env.TNS_ADMIN = TNS_ADMIN;
}

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.fetchAsString = [oracledb.CLOB];

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connection pool
let pool;

async function initializePool() {
  try {
    console.log('[db] Creating connection pool...');
    console.log('[db] Config:', { 
      connectString: DB_CONNECT_STRING, 
      TNS_ADMIN: TNS_ADMIN || 'NOT SET',
      user: DB_USER
    });
    
    const poolConfig = {
      user: DB_USER,
      password: DB_PASSWORD,
      connectString: DB_CONNECT_STRING,
      poolMin: 2,
      poolMax: 10,
      poolIncrement: 1,
      queueTimeout: 15000,
      poolTimeout: 60,
      stmtCacheSize: 30,
      homogeneous: true
    };

    // Add wallet configuration if TNS_ADMIN is set
    if (TNS_ADMIN) {
      poolConfig.configDir = TNS_ADMIN;
      poolConfig.walletLocation = TNS_ADMIN;
      if (WALLET_PASSWORD) {
        poolConfig.walletPassword = WALLET_PASSWORD;
      }
      poolConfig.sslServerDNMatch = true;
    }

    pool = await oracledb.createPool(poolConfig);
    console.log('✅ Oracle connection pool created successfully');
    console.log(`   Pool: min=${pool.poolMin}, max=${pool.poolMax}, increment=${pool.poolIncrement}`);
  } catch (err) {
    console.error('❌ Error creating connection pool:', err);
    throw err;
  }
}

// Helper function to run queries
async function runQuery(sql, binds = [], options = {}) {
  let conn;
  try {
    console.log('[db] Acquiring connection...');
    conn = await pool.getConnection();
    console.log('[db] Executing:', sql);
    
    const result = await conn.execute(sql, binds, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: true,
      ...options
    });
    
    console.log('[db] Executed. Rows:', result.rows ? result.rows.length : 'N/A');
    return result;
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (err) {
        console.error('[db] Error closing connection:', err);
      }
    }
  }
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    database: pool ? 'connected' : 'disconnected',
    poolStats: pool ? {
      connectionsOpen: pool.connectionsOpen,
      connectionsInUse: pool.connectionsInUse
    } : null
  });
});

// Get all claims
app.get('/api/claims', async (req, res) => {
  try {
    const result = await runQuery(
      `SELECT 
        CLAIM_ID,
        CLAIM_NUMBER,
        CLAIM_TYPE,
        CLAIM_SUBTYPE,
        POLICY_NUMBER,
        CUSTOMER_NAME,
        CUSTOMER_EMAIL,
        CUSTOMER_PHONE,
        INCIDENT_DATE,
        STATUS,
        PRIORITY,
        PERIL_CODE,
        ESTIMATED_LOSS,
        AI_CONFIDENCE_SCORE,
        ADJUSTER_ID,
        ADJUSTER_NAME,
        CREATED_DATE
      FROM CLAIMS
      ORDER BY CREATED_DATE DESC`
    );
    
    res.json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (err) {
    console.error('Error fetching claims:', err);
    res.status(500).json({ 
      success: false, 
      error: err.message 
    });
  }
});

// Get single claim by ID
app.get('/api/claims/:id', async (req, res) => {
  try {
    const result = await runQuery(
      `SELECT * FROM CLAIMS WHERE CLAIM_ID = :id`,
      [req.params.id]
    );
    
    if (result.rows.length === 0) {
      res.status(404).json({ 
        success: false, 
        error: 'Claim not found' 
      });
    } else {
      res.json({
        success: true,
        data: result.rows[0]
      });
    }
  } catch (err) {
    console.error('Error fetching claim:', err);
    res.status(500).json({ 
      success: false, 
      error: err.message 
    });
  }
});

// Get all adjusters
app.get('/api/adjusters', async (req, res) => {
  try {
    const result = await runQuery(
      `SELECT 
        ADJUSTER_ID,
        ADJUSTER_NAME,
        EMAIL,
        PHONE,
        SPECIALIZATION,
        HIRE_DATE
      FROM ADJUSTERS
      ORDER BY ADJUSTER_NAME`
    );
    
    res.json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (err) {
    console.error('Error fetching adjusters:', err);
    res.status(500).json({ 
      success: false, 
      error: err.message 
    });
  }
});

// Get all damages
app.get('/api/damages', async (req, res) => {
  try {
    const result = await runQuery(
      `SELECT 
        DAMAGE_ID,
        CLAIM_ID,
        DAMAGE_TYPE,
        DAMAGE_DESCRIPTION,
        SEVERITY,
        ESTIMATED_REPAIR_COST,
        ASSESSMENT_DATE
      FROM DAMAGES
      ORDER BY ASSESSMENT_DATE DESC`
    );
    
    res.json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (err) {
    console.error('Error fetching damages:', err);
    res.status(500).json({ 
      success: false, 
      error: err.message 
    });
  }
});

// Get statistics
app.get('/api/stats', async (req, res) => {
  try {
    // Execute multiple queries for different stats
    const totalClaims = await runQuery(
      `SELECT COUNT(*) as VALUE FROM CLAIMS`
    );
    
    const urgentClaims = await runQuery(
      `SELECT COUNT(*) as VALUE FROM CLAIMS WHERE PRIORITY = 'URGENT'`
    );
    
    const highPriority = await runQuery(
      `SELECT COUNT(*) as VALUE FROM CLAIMS WHERE PRIORITY = 'HIGH'`
    );
    
    const unassigned = await runQuery(
      `SELECT COUNT(*) as VALUE FROM CLAIMS WHERE ADJUSTER_ID IS NULL`
    );
    
    const stats = [
      { METRIC: 'Total Claims', VALUE: totalClaims.rows[0].VALUE },
      { METRIC: 'Urgent Claims', VALUE: urgentClaims.rows[0].VALUE },
      { METRIC: 'High Priority', VALUE: highPriority.rows[0].VALUE },
      { METRIC: 'Unassigned', VALUE: unassigned.rows[0].VALUE }
    ];
    
    res.json({
      success: true,
      data: stats
    });
  } catch (err) {
    console.error('Error fetching stats:', err);
    res.status(500).json({ 
      success: false, 
      error: err.message 
    });
  }
});

// Start server
async function startServer() {
  try {
    await initializePool();
    app.listen(PORT, () => {
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log('🚀 State Farm Backend Server Started');
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log(`📊 Server running:     http://localhost:${PORT}`);
      console.log(`📡 API endpoints:      http://localhost:${PORT}/api/*`);
      console.log(`❤️  Health check:      http://localhost:${PORT}/health`);
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log('Available endpoints:');
      console.log('  GET /health              - Health check');
      console.log('  GET /api/claims          - All claims');
      console.log('  GET /api/claims/:id      - Single claim');
      console.log('  GET /api/adjusters       - All adjusters');
      console.log('  GET /api/damages         - All damages');
      console.log('  GET /api/stats           - Dashboard statistics');
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    });
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('\n⚠️  SIGTERM signal received: closing HTTP server');
  if (pool) {
    await pool.close(10);
    console.log('✅ Database pool closed');
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('\n⚠️  SIGINT signal received: closing HTTP server');
  if (pool) {
    await pool.close(10);
    console.log('✅ Database pool closed');
  }
  process.exit(0);
});

startServer();
