import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();

const DB_USER = process.env.DB_USER || "ADMIN";
const DB_PASSWORD = process.env.DB_PASSWORD;
const DB_CONNECT_STRING = process.env.DB_CONNECT_STRING || "vibecoding_medium";
const TNS_ADMIN = process.env.TNS_ADMIN;
const WALLET_PASSWORD = process.env.WALLET_PASSWORD;

// Configure Oracle client
if (TNS_ADMIN) {
  process.env.TNS_ADMIN = TNS_ADMIN;
}

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.fetchAsString = [oracledb.CLOB];

async function testConnection() {
  let connection;
  
  console.log('🔍 Testing Oracle Database Connection...\n');
  console.log('Configuration:');
  console.log(`  User: ${DB_USER}`);
  console.log(`  Password: ${DB_PASSWORD ? '***' + DB_PASSWORD.slice(-4) : 'NOT SET'}`);
  console.log(`  Connection String: ${DB_CONNECT_STRING}`);
  console.log(`  TNS_ADMIN: ${TNS_ADMIN || 'NOT SET'}`);
  console.log(`  Wallet Password: ${WALLET_PASSWORD ? '***' : 'NOT SET'}\n`);

  try {
    console.log('⏳ Attempting to connect...');
    
    // Connection configuration
    const config = {
      user: DB_USER,
      password: DB_PASSWORD,
      connectString: DB_CONNECT_STRING
    };

    // Add wallet configuration if TNS_ADMIN is set
    if (TNS_ADMIN) {
      config.configDir = TNS_ADMIN;
      config.walletLocation = TNS_ADMIN;
      if (WALLET_PASSWORD) {
        config.walletPassword = WALLET_PASSWORD;
      }
      config.sslServerDNMatch = true;
    }

    connection = await oracledb.getConnection(config);
    console.log('✅ Connection successful!\n');

    // Test CLAIMS table
    console.log('📊 Testing CLAIMS table...');
    const claimsResult = await connection.execute(
      `SELECT COUNT(*) as TOTAL FROM CLAIMS`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    console.log(`✅ CLAIMS table found: ${claimsResult.rows[0].TOTAL} records\n`);

    // Test ADJUSTERS table
    console.log('👔 Testing ADJUSTERS table...');
    const adjustersResult = await connection.execute(
      `SELECT COUNT(*) as TOTAL FROM ADJUSTERS`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    console.log(`✅ ADJUSTERS table found: ${adjustersResult.rows[0].TOTAL} records\n`);

    // Test DAMAGES table
    console.log('💰 Testing DAMAGES table...');
    const damagesResult = await connection.execute(
      `SELECT COUNT(*) as TOTAL FROM DAMAGES`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    console.log(`✅ DAMAGES table found: ${damagesResult.rows[0].TOTAL} records\n`);

    // Sample data from CLAIMS
    console.log('📋 Sample Claims Data (top 5):');
    const sampleClaims = await connection.execute(
      `SELECT CLAIM_NUMBER, CLAIM_TYPE, STATUS, PRIORITY 
       FROM CLAIMS 
       WHERE ROWNUM <= 5
       ORDER BY CREATED_DATE DESC`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    
    if (sampleClaims.rows.length > 0) {
      console.table(sampleClaims.rows);
    } else {
      console.log('⚠️  No claims found in database\n');
    }

    // Test connection pool creation
    console.log('\n🔄 Testing connection pool creation...');
    const pool = await oracledb.createPool({
      user: DB_USER,
      password: DB_PASSWORD,
      connectString: DB_CONNECT_STRING,
      configDir: TNS_ADMIN,
      walletLocation: TNS_ADMIN,
      walletPassword: WALLET_PASSWORD,
      sslServerDNMatch: true,
      poolMin: 1,
      poolMax: 8,
      poolIncrement: 1,
      queueTimeout: 15000,
      poolTimeout: 60,
      stmtCacheSize: 30,
      homogeneous: true
    });
    
    console.log('✅ Connection pool created successfully!');
    console.log(`   Pool size: min=${pool.poolMin}, max=${pool.poolMax}, increment=${pool.poolIncrement}`);
    
    // Close the pool
    await pool.close(0);
    console.log('✅ Connection pool closed\n');

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🎉 All tests passed! Your database is ready.');
    console.log('You can now start the backend server with: npm start\n');

  } catch (err) {
    console.error('\n❌ Connection test failed!');
    console.error('Error:', err.message);
    
    if (err.message.includes('ORA-01017')) {
      console.error('\n💡 Invalid username/password - check your .env file');
    } else if (err.message.includes('ORA-12154')) {
      console.error('\n💡 TNS: could not resolve connect identifier');
      console.error('   - Check your DB_CONNECT_STRING in .env');
      console.error('   - Verify TNS_ADMIN points to wallet directory');
    } else if (err.message.includes('NJS-516')) {
      console.error('\n💡 Wallet/config directory issue');
      console.error('   - Check TNS_ADMIN path in .env');
      console.error('   - Verify wallet files exist in directory');
    } else if (err.message.includes('ORA-12543')) {
      console.error('\n💡 Network/host name resolution issue');
      console.error('   - Check your network connection');
      console.error('   - Verify tnsnames.ora has correct host');
    }
    
    console.error('\n💡 Common solutions:');
    console.error('  1. Check your .env file has correct credentials');
    console.error('  2. Verify Oracle Instant Client is installed');
    console.error('  3. Confirm TNS_ADMIN points to wallet directory');
    console.error('  4. Check wallet password if using encrypted wallet');
    console.error('  5. Verify network connectivity to Oracle Cloud');
    console.error('  6. Ensure your IP is whitelisted in Oracle Cloud ACL\n');
    console.error('Full error details:');
    console.error(err);
    process.exit(1);
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('🔌 Connection closed\n');
      } catch (err) {
        console.error('Error closing connection:', err.message);
      }
    }
  }
}

testConnection();
